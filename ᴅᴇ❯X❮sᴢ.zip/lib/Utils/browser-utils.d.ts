import type { BrowsersMap } from '../Types/index.js';
export declare const Browsers: BrowsersMap;
export declare const getPlatformId: (browser: string) => string;
//# sourceMappingURL=browser-utils.d.ts.map